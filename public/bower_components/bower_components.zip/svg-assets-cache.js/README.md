# svg-assets-cache.js

**:rocket: :zap: :metal: :fire: :smile:**
