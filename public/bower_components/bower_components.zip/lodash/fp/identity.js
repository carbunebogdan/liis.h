var convert = require('./convert'),
    func = convert('identity', require('../identity'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
