var convert = require('./convert'),
    func = convert('fromPairs', require('../fromPairs'));

func.placeholder = require('./placeholder');
module.exports = func;
