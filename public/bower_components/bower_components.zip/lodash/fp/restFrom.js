var convert = require('./convert'),
    func = convert('restFrom', require('../rest'));

func.placeholder = require('./placeholder');
module.exports = func;
