var convert = require('./convert'),
    func = convert('sample', require('../sample'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
