module.exports = require('./xorBy');
